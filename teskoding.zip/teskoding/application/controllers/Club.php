<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * Keys Controller
 * This is a basic Key Management REST controller to make and delete keys
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */

 class Club extends REST_Controller
 {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mdl_club');
        $this->load->library(array('Lib_validation','CodeStatus'));
    }


    public function setClub_post()
    {
        $fieldValid = array(
            "clubname" => $this->post('clubname'),
            "city" => $this->post('city'),
        );

        $result = $this->Mdl_club->setClub($fieldValid);
        $this->response($result, REST_Controller::HTTP_OK);
    }

 }